# docker container rename

> একটি কন্টেইনারের নাম পরিবর্তন করতে ব্যবহৃত হয়।
> আরও তথ্য পাবেন: <https://docs.docker.com/reference/cli/docker/container/rename/>।

- একটি কন্টেইনারের নাম পরিবর্তন করুন:

`docker {{[rename|container rename]}} {{container}} {{new_name}}`

- সাহায্য প্রদর্শন:

`docker {{[rename|container rename]}} --help`
