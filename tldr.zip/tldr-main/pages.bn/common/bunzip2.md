# bunzip2

> এই কমান্ডটি `bzip2 --decompress` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr bzip2`
