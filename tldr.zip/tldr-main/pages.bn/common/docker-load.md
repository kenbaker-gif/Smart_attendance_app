# docker load

> এই কমান্ডটি `docker image load` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker image load`
