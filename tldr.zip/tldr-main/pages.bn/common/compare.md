# compare

> এই কমান্ডটি `magick compare` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr magick compare`
