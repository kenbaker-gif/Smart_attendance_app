# docker container top

> একটি কন্টেইনারের চলমান প্রসেসসমূহ দেখুন।
> আরও তথ্য পাবেন: <https://docs.docker.com/reference/cli/docker/container/top/>।

- একটি কন্টেইনারের চলমান প্রসেসসমূহ দেখুন:

`docker {{[top|container top]}} {{container}}`

- সাহায্য প্রদর্শন:

`docker {{[top|container top]}} --help`
