# brew abv

> এই কমান্ডটি `brew info` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr brew info`
