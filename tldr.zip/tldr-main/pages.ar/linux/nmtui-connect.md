# nmtui-connect

> هذا الأمر هو اسم مستعار لـ `nmtui connect`.

- إعرض التوثيقات للأمر الأصلي:

`tldr nmtui`
