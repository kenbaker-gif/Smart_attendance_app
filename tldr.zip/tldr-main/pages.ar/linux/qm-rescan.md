# qm rescan

> هذا الأمر هو اسم مستعار لـ `qm disk rescan`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm disk`
