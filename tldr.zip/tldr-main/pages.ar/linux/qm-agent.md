# qm agent

> هذا الأمر هو اسم مستعار لـ `qm guest cmd`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm guest`
