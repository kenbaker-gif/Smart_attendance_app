# pacman -F

> هذا الأمر هو اسم مستعار لـ `pacman --files`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman files`
