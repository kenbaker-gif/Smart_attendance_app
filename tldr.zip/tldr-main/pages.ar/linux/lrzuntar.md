# lrzuntar

> هذا الأمر هو اسم مستعار لـ `lrztar --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr lrztar`
