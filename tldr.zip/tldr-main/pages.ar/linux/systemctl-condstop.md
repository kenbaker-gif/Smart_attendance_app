# systemctl condstop

> هذا الأمر هو اسم مستعار لـ `systemctl stop`.

- إعرض التوثيقات للأمر الأصلي:

`tldr systemctl stop`
