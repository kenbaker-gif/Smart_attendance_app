# ss

> أداة للتحقيق في المقابس (Sockets) و المنافذ.
> لمزيد من التفاصيل: <https://manned.org/ss>.

- عرض جميع مقابس TCP/UDP/RAW/UNIX:

`ss {{[-a|--all]}} {{--tcp|--udp|--raw|--unix}}`

- تصفية مقابس TCP حسب الحالات، تضمين/استبعاد:

`ss {{state|exclude}} {{bucket|big|connected|synchronized|...}}`

- عرض جميع مقابس TCP المتصلة بمنفذ HTTPS المحلي (443):

`ss {{[-t|--tcp]}} src :{{443}}`

- عرض جميع مقابس TCP التي تستمع على المنفذ المحلي 8080:

`ss {{[-lt|--listening --tcp]}} src :{{8080}}`

- عرض جميع مقابس TCP مع العمليات المتصلة بمنفذ SSH الخارجي:

`ss {{[-pt|--processes --tcp]}} dst :{{ssh}}`

- عرض جميع مقابس UDP المتصلة بمنفذ مصدر ومنفذ وجهة محددين:

`ss {{[-u|--udp]}} 'sport == :{{source_port}} and dport == :{{destination_port}}'`

- عرض جميع مقابس TCP IPv4 المتصلة محليًا على الشبكة الفرعية 192.168.0.0/16:

`ss {{[-4t|--ipv4 --tcp]}} src {{192.168/16}}`

- إنهاء اتصال مقبس IPv4 أو IPv6 مع عنوان الوجهة 192.168.1.17 والمنفذ 8080:

`ss {{[-K|--kill]}} dst {{192.168.1.17}} dport = {{8080}}`
