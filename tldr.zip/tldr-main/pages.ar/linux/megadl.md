# megadl

> هذا الأمر هو اسم مستعار لـ `megatools-dl`.

- إعرض التوثيقات للأمر الأصلي:

`tldr megatools-dl`
