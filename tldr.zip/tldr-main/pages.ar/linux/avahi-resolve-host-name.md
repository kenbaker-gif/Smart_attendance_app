# avahi-resolve-host-name

> هذا الأمر هو اسم مستعار لـ `avahi-resolve --name`.

- إعرض التوثيقات للأمر الأصلي:

`tldr avahi-resolve`
