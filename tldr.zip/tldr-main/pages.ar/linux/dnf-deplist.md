# dnf deplist

> هذا الأمر هو اسم مستعار لـ `dnf repoquery --deplist`.

- إعرض التوثيقات للأمر الأصلي:

`tldr dnf repoquery`
