# pacman -S

> هذا الأمر هو اسم مستعار لـ `pacman --sync`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman sync`
