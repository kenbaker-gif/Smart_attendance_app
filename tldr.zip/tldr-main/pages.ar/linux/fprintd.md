# fprintd

> خدمة إدارة بصمات الأصابع.
> لمزيد من التفاصيل: <https://fprint.freedesktop.org/>.

- عرض صفحة المساعدة لـ `fprintd`:

`man fprintd`
