# linux64

> هذا الأمر هو اسم مستعار لـ `setarch linux64`.

- إعرض التوثيقات للأمر الأصلي:

`tldr setarch`
