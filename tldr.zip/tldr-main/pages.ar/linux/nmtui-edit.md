# nmtui-edit

> هذا الأمر هو اسم مستعار لـ `nmtui edit`.

- إعرض التوثيقات للأمر الأصلي:

`tldr nmtui`
