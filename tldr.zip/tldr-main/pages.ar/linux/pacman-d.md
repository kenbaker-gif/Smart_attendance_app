# pacman -D

> هذا الأمر هو اسم مستعار لـ `pacman --database`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman database`
