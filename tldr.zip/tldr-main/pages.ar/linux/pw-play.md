# pw-play

> هذا الأمر هو اسم مستعار لـ `pw-cat --playback`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pw-cat`
