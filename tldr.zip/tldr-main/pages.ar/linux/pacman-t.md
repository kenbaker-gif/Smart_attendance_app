# pacman -T

> هذا الأمر هو اسم مستعار لـ `pacman --deptest`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman deptest`
