# systemctl condrestart

> هذا الأمر هو اسم مستعار لـ `systemctl try-restart`.

- إعرض التوثيقات للأمر الأصلي:

`tldr systemctl try-restart`
