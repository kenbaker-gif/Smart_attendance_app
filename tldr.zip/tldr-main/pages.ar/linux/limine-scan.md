# limine-scan

> هذا الأمر هو اسم مستعار لـ `limine-entry-tool --scan`.

- إعرض التوثيقات للأمر الأصلي:

`tldr limine-entry-tool`
