# ip route show

> هذا الأمر هو اسم مستعار لـ `ip route list`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ip route list`
