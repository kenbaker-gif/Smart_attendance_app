# mkfs.vfat

> هذا الأمر هو اسم مستعار لـ `mkfs.fat`.

- إعرض التوثيقات للأمر الأصلي:

`tldr mkfs.fat`
