# systemd-umount

> هذا الأمر هو اسم مستعار لـ `systemd-mount --umount`.

- إعرض التوثيقات للأمر الأصلي:

`tldr systemd-mount`
