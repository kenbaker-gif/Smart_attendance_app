# pw-record

> هذا الأمر هو اسم مستعار لـ `pw-cat --record`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pw-cat`
