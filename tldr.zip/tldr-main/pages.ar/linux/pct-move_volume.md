# pct move_volume

> هذا الأمر هو اسم مستعار لـ `pct move-volume`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pct move-volume`
