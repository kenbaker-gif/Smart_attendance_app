# ubuntu-bug

> هذا الأمر هو اسم مستعار لـ `apport-bug`.

- إعرض التوثيقات للأمر الأصلي:

`tldr apport-bug`
