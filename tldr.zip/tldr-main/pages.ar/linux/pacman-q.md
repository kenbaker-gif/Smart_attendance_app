# pacman -Q

> هذا الأمر هو اسم مستعار لـ `pacman --query`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman query`
