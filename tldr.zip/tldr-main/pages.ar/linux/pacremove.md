# pacremove

> هذا الأمر هو اسم مستعار لـ `pactrans --remove`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pactrans`
