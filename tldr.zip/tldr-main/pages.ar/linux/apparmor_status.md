# apparmor_status

> هذا الأمر هو اسم مستعار لـ `aa-status`.

- إعرض التوثيقات للأمر الأصلي:

`tldr aa-status`
