# cs2

> هذا الأمر هو اسم مستعار لـ `counter strike 2`.

- إعرض التوثيقات للأمر الأصلي:

`tldr counter strike 2`
