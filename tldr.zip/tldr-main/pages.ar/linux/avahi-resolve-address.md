# avahi-resolve-address

> هذا الأمر هو اسم مستعار لـ `avahi-resolve --address`.

- إعرض التوثيقات للأمر الأصلي:

`tldr avahi-resolve`
