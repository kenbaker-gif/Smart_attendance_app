# npm stop

> هذا الأمر هو اسم مستعار لـ `npm run stop`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm run`
