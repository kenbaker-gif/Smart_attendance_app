# mapfile

> هذا الأمر هو اسم مستعار لـ `readarray`.

- إعرض التوثيقات للأمر الأصلي:

`tldr readarray`
