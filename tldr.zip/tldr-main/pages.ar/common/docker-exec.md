# docker exec

> هذا الأمر هو اسم مستعار لـ `docker container exec`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container exec`
