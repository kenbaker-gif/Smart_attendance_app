# npm run-script

> هذا الأمر هو اسم مستعار لـ `npm run`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm run`
