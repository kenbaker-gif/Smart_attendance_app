# montage

> هذا الأمر هو اسم مستعار لـ `magick montage`.

- إعرض التوثيقات للأمر الأصلي:

`tldr magick montage`
