# bun rm

> هذا الأمر هو اسم مستعار لـ `bun remove`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bun remove`
