# bun c

> هذا الأمر هو اسم مستعار لـ `bun create`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bun create`
