# podman image pull

> هذا الأمر هو اسم مستعار لـ `podman pull`.

- إعرض التوثيقات للأمر الأصلي:

`tldr podman pull`
