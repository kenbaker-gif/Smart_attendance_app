# docker save

> هذا الأمر هو اسم مستعار لـ `docker image save`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image save`
