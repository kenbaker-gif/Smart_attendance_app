# docker container top

> هذا الأمر هو اسم مستعار لـ `docker top`.
> لمزيد من التفاصيل: <https://docs.docker.com/reference/cli/docker/container/top/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker top`
