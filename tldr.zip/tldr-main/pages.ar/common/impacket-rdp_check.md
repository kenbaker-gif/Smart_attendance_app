# impacket-rdp_check

> هذا الأمر هو اسم مستعار لـ `rdp_check.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr rdp_check.py`
