# xml p2x

> هذا الأمر هو اسم مستعار لـ `xml depyx`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xml depyx`
