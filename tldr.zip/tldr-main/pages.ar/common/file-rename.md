# file-rename

> هذا الأمر هو اسم مستعار لـ `rename`.

- إعرض التوثيقات للأمر الأصلي:

`tldr {{[-p|--platform]}} common rename`
