# docker start

> هذا الأمر هو اسم مستعار لـ `docker container start`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container start`
