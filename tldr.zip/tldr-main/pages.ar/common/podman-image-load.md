# podman image load

> هذا الأمر هو اسم مستعار لـ `podman load`.

- إعرض التوثيقات للأمر الأصلي:

`tldr podman load`
