# git continue

> هذا الأمر هو اسم مستعار لـ `git abort`.

- إعرض التوثيقات للأمر الأصلي:

`tldr git abort`
