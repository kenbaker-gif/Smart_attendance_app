# llvm-objdump

> هذا الأمر هو اسم مستعار لـ `objdump`.

- إعرض التوثيقات للأمر الأصلي:

`tldr objdump`
