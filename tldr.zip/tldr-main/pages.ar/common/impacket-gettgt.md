# impacket-getTGT

> هذا الأمر هو اسم مستعار لـ `getTGT.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr getTGT.py`
