# rustup install

> هذا الأمر هو اسم مستعار لـ `rustup toolchain install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr rustup toolchain`
