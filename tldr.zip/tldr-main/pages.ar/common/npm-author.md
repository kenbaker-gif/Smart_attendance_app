# npm author

> هذا الأمر هو اسم مستعار لـ `npm owner`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm owner`
