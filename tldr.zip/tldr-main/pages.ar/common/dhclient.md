# dhclient

> عميل DHCP.
> لمزيد من التفاصيل: <https://manned.org/dhclient>.

- الحصول على عنوان IP لواجهة `eth0`:

`sudo dhclient {{eth0}}`

- تحرير عنوان IP لواجهة `eth0`:

`sudo dhclient -r {{eth0}}`
