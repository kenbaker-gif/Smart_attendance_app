# zegrep

> هذا الأمر هو اسم مستعار لـ `zgrep --extended-regexp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr zgrep`
