# impacket-GetUserSPNs

> هذا الأمر هو اسم مستعار لـ `GetUserSPNs.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr GetUserSPNs.py`
