# jupyterlab

> هذا الأمر هو اسم مستعار لـ `jupyter lab`.

- إعرض التوثيقات للأمر الأصلي:

`tldr jupyter lab`
