# impacket-GetNPUsers

> هذا الأمر هو اسم مستعار لـ `GetNPUsers.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr GetNPUsers.py`
