# impacket-rpcmap

> هذا الأمر هو اسم مستعار لـ `rpcmap.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr rpcmap.py`
