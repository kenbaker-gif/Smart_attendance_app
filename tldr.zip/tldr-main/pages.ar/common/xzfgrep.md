# xzfgrep

> هذا الأمر هو اسم مستعار لـ `xzgrep --fixed-strings`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xzgrep`
