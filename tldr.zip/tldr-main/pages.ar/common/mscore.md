# mscore

> هذا الأمر هو اسم مستعار لـ `musescore`.

- إعرض التوثيقات للأمر الأصلي:

`tldr musescore`
