# impacket-ping

> هذا الأمر هو اسم مستعار لـ `ping.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ping.py`
