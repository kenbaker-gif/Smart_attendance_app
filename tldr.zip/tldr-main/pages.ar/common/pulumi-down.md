# pulumi down

> هذا الأمر هو اسم مستعار لـ `pulumi destroy`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pulumi destroy`
