# gh a11y

> هذا الأمر هو اسم مستعار لـ `gh accessibility`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh accessibility`
