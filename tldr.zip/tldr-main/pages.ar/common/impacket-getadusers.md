# impacket-GetADUsers

> هذا الأمر هو اسم مستعار لـ `GetADUsers.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr GetADUsers.py`
