# lzcat

> هذا الأمر هو اسم مستعار لـ `xz --format lzma --decompress --stdout`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xz`
