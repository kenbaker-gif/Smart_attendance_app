# compare

> هذا الأمر هو اسم مستعار لـ `magick compare`.

- إعرض التوثيقات للأمر الأصلي:

`tldr magick compare`
