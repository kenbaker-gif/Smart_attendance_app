# robo

> مشغل مهام PHP.
> لمزيد من التفاصيل: <https://robo.li/getting-started.html>.

- عرض قائمة الأوامر المتوفرة:

`robo list`

- تشغيل أمر محدد:

`robo {{foo}}`

- محاكاة تشغيل أمر محدد:

`robo --simulate {{foo}}`
