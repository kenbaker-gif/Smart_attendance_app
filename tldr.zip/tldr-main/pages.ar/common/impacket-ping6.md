# impacket-ping6

> هذا الأمر هو اسم مستعار لـ `ping6.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ping6.py`
