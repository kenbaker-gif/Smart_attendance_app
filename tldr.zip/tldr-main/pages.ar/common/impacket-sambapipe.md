# impacket-sambaPipe

> هذا الأمر هو اسم مستعار لـ `sambaPipe.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr sambaPipe.py`
