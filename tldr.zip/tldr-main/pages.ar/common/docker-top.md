# docker top

> هذا الأمر هو اسم مستعار لـ `docker container top`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container top`
