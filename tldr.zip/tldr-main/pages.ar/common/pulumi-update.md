# pulumi update

> هذا الأمر هو اسم مستعار لـ `pulumi up`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pulumi up`
