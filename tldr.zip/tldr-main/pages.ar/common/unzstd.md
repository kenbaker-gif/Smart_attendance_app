# unzstd

> هذا الأمر هو اسم مستعار لـ `zstd --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr zstd`
