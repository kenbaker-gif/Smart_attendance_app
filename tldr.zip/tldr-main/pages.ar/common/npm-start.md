# npm start

> هذا الأمر هو اسم مستعار لـ `npm run start`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm run`
