# docker rm

> هذا الأمر هو اسم مستعار لـ `docker container rm`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container rm`
