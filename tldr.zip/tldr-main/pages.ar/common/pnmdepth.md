# pnmdepth

> هذا الأمر هو اسم مستعار لـ `pamdepth`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pamdepth`
