# docker rmi

> هذا الأمر هو اسم مستعار لـ `docker image rm`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image rm`
