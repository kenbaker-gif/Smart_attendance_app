# egrep

> هذا الأمر هو اسم مستعار لـ `grep --extended-regexp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr grep`
