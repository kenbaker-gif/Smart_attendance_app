# zstdmt

> هذا الأمر هو اسم مستعار لـ `zstd --threads 0`.

- إعرض التوثيقات للأمر الأصلي:

`tldr zstd`
