# bun list

> هذا الأمر هو اسم مستعار لـ `bun pm ls`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bun pm ls`
