# impacket-getArch

> هذا الأمر هو اسم مستعار لـ `getArch.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr getArch.py`
