# git stage

> هذا الأمر هو اسم مستعار لـ `git add`.

- إعرض التوثيقات للأمر الأصلي:

`tldr git add`
