# pnmtoplainpnm

> هذا الأمر هو اسم مستعار لـ `pamtopnm -plain`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pamtopnm`
