# docker commit

> هذا الأمر هو اسم مستعار لـ `docker container commit`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container commit`
