# zcat

> هذا الأمر هو اسم مستعار لـ `gzip --stdout --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gzip`
