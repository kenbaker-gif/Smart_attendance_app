# impacket-sniff

> هذا الأمر هو اسم مستعار لـ `sniff.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr sniff.py`
