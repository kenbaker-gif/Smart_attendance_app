# zstdcat

> هذا الأمر هو اسم مستعار لـ `zstd --decompress --stdout --force`.

- إعرض التوثيقات للأمر الأصلي:

`tldr zstd`
