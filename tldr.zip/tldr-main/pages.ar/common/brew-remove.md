# brew remove

> هذا الأمر هو اسم مستعار لـ `brew uninstall`.

- إعرض التوثيقات للأمر الأصلي:

`tldr brew uninstall`
