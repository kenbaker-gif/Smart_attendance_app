# import

> هذا الأمر هو اسم مستعار لـ `magick import`.

- إعرض التوثيقات للأمر الأصلي:

`tldr magick import`
