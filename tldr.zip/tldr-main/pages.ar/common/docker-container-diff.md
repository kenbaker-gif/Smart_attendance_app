# docker container diff

> هذا الأمر هو اسم مستعار لـ `docker diff`.
> لمزيد من التفاصيل: <https://docs.docker.com/reference/cli/docker/container/diff/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker diff`
