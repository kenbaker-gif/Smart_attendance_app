# impacket-mqtt_check

> هذا الأمر هو اسم مستعار لـ `mqtt_check.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr mqtt_check.py`
