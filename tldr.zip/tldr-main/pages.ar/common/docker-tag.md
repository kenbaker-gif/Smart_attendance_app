# docker tag

> هذا الأمر هو اسم مستعار لـ `docker image tag`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image tag`
