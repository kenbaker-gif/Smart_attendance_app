# unlzma

> هذا الأمر هو اسم مستعار لـ `xz --format lzma --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xz`
