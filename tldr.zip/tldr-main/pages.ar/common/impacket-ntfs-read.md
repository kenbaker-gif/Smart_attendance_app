# impacket-ntfs-read

> هذا الأمر هو اسم مستعار لـ `ntfs-read.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ntfs-read.py`
