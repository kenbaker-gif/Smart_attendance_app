# minetestserver

> هذا الأمر هو اسم مستعار لـ `luanti --server`.

- إعرض التوثيقات للأمر الأصلي:

`tldr luanti`
