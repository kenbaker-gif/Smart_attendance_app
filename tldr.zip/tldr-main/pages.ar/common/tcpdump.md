# tcpdump

> عرض وتحليل حركة المرور على الشبكة.
> لمزيد من التفاصيل: <https://www.tcpdump.org/manpages/tcpdump.1.html>.

- عرض قائمة بواجهات الشبكة المتوفرة:

`tcpdump {{[-D|--list-interfaces]}}`

- التقاط حركة المرور لواجهة شبكة محددة:

`sudo tcpdump {{[-i|--interface]}} {{eth0}}`

- التقاط جميع حركة مرور TCP مع عرض المحتويات (ASCII) في وحدة التحكم:

`tcpdump -A tcp`

- التقاط حركة المرور من أو إلى مضيف محدد:

`tcpdump host {{www.example.com}}`

- التقاط حركة المرور من واجهة معينة مع مصدر، وجهة ومنفذ وجهة محددين:

`sudo tcpdump {{[-i|--interface]}} {{eth0}} src {{192.168.1.1}} and dst {{192.168.1.2}} and dst port {{80}}`

- التقاط حركة المرور لشبكة محددة:

`tcpdump net {{192.168.1.0/24}}`

- التقاط جميع حركة المرور باستثناء حركة المرور على المنفذ 22 وحفظها في ملف:

`tcpdump -w {{dumpfile.pcap}} port not {{22}}`

- قراءة البيانات من ملف محدد:

`tcpdump -r {{dumpfile.pcap}}`
