# gh at

> هذا الأمر هو اسم مستعار لـ `gh attestation`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh attestation`
