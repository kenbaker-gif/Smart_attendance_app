# minetest

> هذا الأمر هو اسم مستعار لـ `luanti`.

- إعرض التوثيقات للأمر الأصلي:

`tldr luanti`
