# identify

> هذا الأمر هو اسم مستعار لـ `magick identify`.

- إعرض التوثيقات للأمر الأصلي:

`tldr magick identify`
