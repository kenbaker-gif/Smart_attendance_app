# piodebuggdb

> هذا الأمر هو اسم مستعار لـ `pio debug --interface gdb`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pio debug`
