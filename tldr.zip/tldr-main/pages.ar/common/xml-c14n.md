# xml c14n

> هذا الأمر هو اسم مستعار لـ `xml canonic`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xml canonic`
