# rgrep

> هذا الأمر هو اسم مستعار لـ `grep --recursive`.

- إعرض التوثيقات للأمر الأصلي:

`tldr grep`
