# docker rename

> هذا الأمر هو اسم مستعار لـ `docker container rename`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container rename`
