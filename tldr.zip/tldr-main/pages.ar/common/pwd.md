# pwd

> اطبع اسم الدليل الحالي.
> لمزيد من التفاصيل: <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>.

- اطبع اسم الدليل الحالي:

`pwd`

- اطبع اسم الدليل الحالي و حل جميع الروابط اللينة (وبمعنى آخر إظهار المسارالفعلي):

`pwd {{[-P|--physical]}}`
