# libreoffice

> هذا الأمر هو اسم مستعار لـ `soffice`.

- إعرض التوثيقات للأمر الأصلي:

`tldr soffice`
