# ypchpass

> هذا الأمر هو اسم مستعار لـ `chpass`.

- إعرض التوثيقات للأمر الأصلي:

`tldr chpass`
