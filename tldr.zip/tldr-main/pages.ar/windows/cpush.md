# cpush

> هذا الأمر هو اسم مستعار لـ `choco push`.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco push`
