# slmgr

> هذا الأمر هو اسم مستعار لـ `slmgr.vbs`.

- إعرض التوثيقات للأمر الأصلي:

`tldr slmgr.vbs`
