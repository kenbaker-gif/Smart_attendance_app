# iwr

> هذا الأمر هو اسم مستعار لـ `invoke-webrequest`.

- إعرض التوثيقات للأمر الأصلي:

`tldr invoke-webrequest`
