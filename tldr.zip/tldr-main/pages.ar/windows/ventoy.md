# ventoy

> هذا الأمر هو اسم مستعار لـ `Ventoy2Disk`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ventoy2disk`
