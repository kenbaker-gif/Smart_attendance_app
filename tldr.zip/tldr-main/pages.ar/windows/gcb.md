# gcb

> هذا الأمر هو اسم مستعار لـ `Get-Clipboard`.

- إعرض التوثيقات للأمر الأصلي:

`tldr get-clipboard`
