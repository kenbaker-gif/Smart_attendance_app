# pwsh where

> هذا الأمر هو اسم مستعار لـ `Where-Object`.

- إعرض التوثيقات للأمر الأصلي:

`tldr Where-Object`
