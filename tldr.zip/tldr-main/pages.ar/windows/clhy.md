# clhy

> هذا الأمر هو اسم مستعار لـ `Clear-History`.

- إعرض التوثيقات للأمر الأصلي:

`tldr Clear-History`
