# h

> هذا الأمر هو اسم مستعار لـ `Get-History`.

- إعرض التوثيقات للأمر الأصلي:

`tldr Get-History`
